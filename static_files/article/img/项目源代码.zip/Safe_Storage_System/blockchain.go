package main

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math/big"
	"os"
	"strconv"
	"sync"
	"time"
)

var head *DataNode
var last *DataNode

type DataNode struct {
	data DATA
	next *DataNode
}

type DATA struct {
	DeviceId string //iot设备号
	UserId   string
	SavedAt  time.Time
	Serial   int
	Hash     string
	StoreOn  string
	ModNum   *big.Int
}

type Block struct {
	Index              int
	SavedAt            time.Time
	Hash               string
	PrevHash           string
	BlockGenerator     int
	NextBlockGenerator int
	Data               []DATA
}

var prevBlock Block

var mutex = &sync.Mutex{}

func handleBlock(test []DATA) {

	mutex.Lock()
	prevBlock = getPrevblock()
	newBlock := generateBlock(prevBlock, test)
	if isBlockValid(newBlock, prevBlock) {
		storeBlock(newBlock)
		fmt.Println("BlockGenerator !!!!!!")
		fmt.Println(config.NodeId)
		fmt.Println(newBlock.BlockGenerator)
		tmpData, _ := json.Marshal(newBlock)
		broadcastBlock(tmpData)
	}
	mutex.Unlock()
}

func getPrevblock() Block {

	file, err := os.Open("backup.txt")
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()
	br := bufio.NewReader(file)

	var lastLine []byte
	for {
		currentLine, _, c := br.ReadLine()
		if c == io.EOF {
			//fmt.Println("&&&&&&&&&&&")
			//fmt.Println(string(last_line))
			var newBlock Block
			err1 := json.Unmarshal(lastLine, &newBlock)
			if err1 != nil {
				fmt.Println(err)
			}
			//fmt.Println("*********")
			//fmt.Println(newBlock)
			return newBlock
		}
		lastLine = currentLine
	}
}

func storeBlock(newBlock Block) {
	fd, _ := os.OpenFile("backup.txt", os.O_RDWR|os.O_CREATE|os.O_APPEND, 0755)
	tmpData, _ := json.Marshal(newBlock)
	InsertBlock(&newBlock)
	fd.Write(tmpData)
	fd.Write([]byte("\n"))
	fd.Close()
}

// make sure block is valid by checking index, and comparing the hash of the previous block
func isBlockValid(newBlock, oldBlock Block) bool {
	if oldBlock.Index+1 != newBlock.Index {
		return false
	}

	if oldBlock.Hash != newBlock.PrevHash {
		return false
	}

	if calculateHash(newBlock) != newBlock.Hash {
		return false
	}

	return true
}

// SHA256 hasing
func calculateHash(block Block) string {
	tmpData, _ := json.Marshal(block.Data)
	record := strconv.Itoa(block.Index) + time.Time.String(block.SavedAt) + string(tmpData) + block.PrevHash + strconv.Itoa(block.BlockGenerator) + strconv.Itoa(block.NextBlockGenerator)
	h := sha256.New()
	h.Write([]byte(record))
	hashed := h.Sum(nil)
	return hex.EncodeToString(hashed)
}

// create a new block using previous block's hash
func generateBlock(oldBlock Block, Data []DATA) Block {

	var newBlock Block

	t := time.Now()

	newBlock.Index = oldBlock.Index + 1
	newBlock.SavedAt = t
	newBlock.PrevHash = oldBlock.Hash
	//genius
	if oldBlock.Hash == "" {
		newBlock.BlockGenerator = 0
		newBlock.NextBlockGenerator = 1
	} else {
		newBlock.BlockGenerator = (oldBlock.BlockGenerator + 1) % 7
		newBlock.NextBlockGenerator = (oldBlock.BlockGenerator + 2) % 7
	}

	//newBlock.Data = Data
	for _, data := range Data {
		if data != (DATA{}) {
			newBlock.Data = append(newBlock.Data, data)
			//newBlock.Data[i].DeviceId = data.DeviceId
			//newBlock.Data[i].UserId = data.UserId
			//newBlock.Data[i].SavedAt = data.SavedAt
			//newBlock.Data[i].Serial = data.Serial
			//newBlock.Data[i].Hash = data.Hash
			//newBlock.Data[i].StoreOn = data.StoreOn
			//newBlock.Data[i].ModNum = data.ModNum
		}
	}

	newBlock.Hash = calculateHash(newBlock)
	return newBlock
}
