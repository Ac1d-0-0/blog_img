package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/big"
	"mime/multipart"
	"net"
	"net/http"
	"strconv"
	"time"
)

const (
	RequestTimeout = 1 * time.Second
	SendDuration   = 2 * time.Second
)

var (
	urlList = map[int]string{}
	myURL   string
	node    *Node
	data    []DATA
	config  *Config
	sig     chan struct{}
)

type Config struct {
	P2PPort     int      `json:"p2p_port"`
	HttpPort    int      `json:"http_port"`
	NodeId      int      `json:"node_id"`
	AddressBook []string `json:"address_book"`
}

//查询本机的外网ip
func GetOutboundIP() string {
	conn, err := net.Dial("udp", "8.8.8.8:80")
	if err != nil {
		log.Fatal(err)
	}
	defer conn.Close()

	localAddr := conn.LocalAddr().(*net.UDPAddr)

	return localAddr.IP.String()
}

//创建创世区块
func setGenius() {
	fmt.Println("创建创世区块")
	var genius []DATA
	bigint := big.NewInt(100000)
	genius = append(genius, DATA{"xxxx", "xxxx", time.Now(), 1, "xxxxxxxxxxxxxxxx", "http://10.122.196.144:5001", bigint})
	handleBlock(genius)
}

//更新并获得自己的URL
func updateConnectionInfo(nodeId int, URL string) {
	log.Printf("Node %d updated its URL to %s", nodeId, URL)
	urlList[nodeId] = URL
}

//初始化节点
func initNode() {
	sig = make(chan struct{}, 1)
	node = makeNode(config.P2PPort)
	myURL = node.URL
	log.Printf("I am %s\n", myURL)
	time.Sleep(time.Second * 10)
	updateConnectionInfo(config.NodeId, myURL)
	buildTraverser()
	for nodeId, target := range config.AddressBook {
		if nodeId == config.NodeId {
			continue
		}
		//对地址本中一个节点发送消息，通知自己地址与id
		go func(target string) {
			for {
				log.Printf("Start to send postConnectionInfo to %s", target)
				buf := new(bytes.Buffer)
				w := multipart.NewWriter(buf)
				_ = w.WriteField("node_id", strconv.Itoa(config.NodeId))
				_ = w.WriteField("URL", myURL)
				_ = w.Close()
				req, err := http.NewRequest("POST", target+"/postConnectionInfo", buf)
				if err != nil {
					// TODO: Handle error
					panic(err)
				}
				req.Header.Set("Content-Type", w.FormDataContentType())
				client := http.Client{Timeout: RequestTimeout}
				resp, err := client.Do(req)
				if err != nil || resp.StatusCode != 200 {
					log.Printf("Failed to send postConnectionInfo to %s", target)
					time.Sleep(SendDuration)
					continue
				}
				break
			}
		}(target)
	}
	//收到postConnectionInfo函数通过管道传入的sig后，判定当前上线节点数并生成初始区块。
	go func() {
		for {
			select {
			case <-sig:
				log.Printf("%d nodes connected", len(urlList))
				if len(urlList) == 7 {
					if config.NodeId == 0 {
						setGenius()
					}
					bigint := big.NewInt(100000)
					initD := DATA{"xxx", "xxx", time.Now(), -1, "xxxxxxxxxxx", "xxxxx", bigint}
					head = &DataNode{initD, nil}
					last = head
					break
				}
			}
		}
	}()
}

//接受data和slice，由iotServer调用
func receiveSlice(newSlice []byte, newData []byte) {
	//接收信息以及slice
	var dataBuf DATA
	err := json.Unmarshal(newData, &dataBuf)
	if err != nil {
		log.Println(err)
	}
	StoreSlice(newSlice, dataBuf)
	tempDataNode := &DataNode{
		data: dataBuf,
		next: nil,
	}
	if last != nil {
		last.next = tempDataNode
	}
	last = tempDataNode
}

//处理json以及存储分片
func generateData() []DATA {
	for i := 0; i < 10; i++ {
		if head.next == nil || head == last {
			return data
		}
		data = append(data, head.next.data)
		head = head.next
	}
	return data
}

func getToken() {
	fmt.Println("节点接收到Token")
	time.Sleep(time.Second * 30)
	for {
		if head != last {
			handleBlock(generateData())
			break
		}
		fmt.Println("节点暂未收到slice，等待中....")
		time.Sleep(time.Second * 5)
	}
}

//读取配置信息。
func readConfig() {
	data, err := ioutil.ReadFile("./config.json")
	if err != nil {
		panic(err)
	}
	err = json.Unmarshal(data, &config)
	if err != nil {
		panic(err)
	}
}

func main() {
	readConfig()
	initNode()
	httpServer()
	for {
		println("持续存活")
		//noticePack(100)
		time.Sleep(time.Second * 10)
	}
}
