package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/big"
	"time"
)

func encrypt(coefficient [][]*big.Int, messageStr string) ([]*big.Int, *big.Int) {
	baseNum := big.NewInt(10) //内部以十进制计算
	var splitLen [4]int       // 每个分片的长度
	fmt.Print("message  :")
	fmt.Println(messageStr) // message的字符串形式

	var L int
	if len(messageStr)%4 == 0 {
		L = len(messageStr) / 4
		for i := 0; i < 4; i++ {
			splitLen[i] = L
		}
	} else {
		L = len(messageStr)/4 + 1
		if len(messageStr)%4 == 1 {
			splitLen[0] = L
			for i := 1; i < 4; i++ {
				splitLen[i] = L - 1
			}
		}
		if len(messageStr)%4 == 2 {
			splitLen[0] = L
			splitLen[1] = L
			for i := 2; i < 4; i++ {
				splitLen[i] = L - 1
			}
		}
		if len(messageStr)%4 == 3 {
			splitLen[3] = L - 1
			for i := 0; i < 3; i++ {
				splitLen[i] = L
			}
		}
	}

	modNum := big.NewInt(1) // 模数p
	for i := 0; i < L; i++ {
		modNum.Mul(modNum, baseNum)
	}

	one := big.NewInt(1)
	two := big.NewInt(2)
	p := modNum
	p.Add(p, one)
	for {
		if p.ProbablyPrime(4) {
			break
		}
		p.Add(p, two)
	}
	fmt.Println("p =", p)

	// 将明文消息分成四份
	var splitMessage [4]*big.Int
	temp := 0
	for i := 0; i < 4; i++ {
		tmpInt := big.NewInt(0)
		//在每段 splitMessage 前加一个1，防止下面计算的时候最高位的0丢失
		tmpStr := "1" + messageStr[temp:temp+splitLen[i]]
		tmpInt, _ = tmpInt.SetString(tmpStr, 2)
		splitMessage[i] = tmpInt
		temp += splitLen[i]
	}

	fmt.Print("splitMessage:")
	fmt.Println(splitMessage)

	ciphertext := make([]*big.Int, 7)
	for i := 0; i < 7; i++ {
		var temp1 *big.Int
		temp1 = new(big.Int)
		ciphertext[i] = big.NewInt(0)
		for j := 0; j < 4; j++ {
			temp1 = big.NewInt(0)
			temp1.Mul(coefficient[i][j], splitMessage[j])
			ciphertext[i].Add(ciphertext[i], temp1)
		}
		ciphertext[i].Mod(ciphertext[i], p)
	}
	fmt.Print("ciphertext: ")
	fmt.Println(ciphertext)
	return ciphertext, p
}

func decrypt(coefficient [][]*big.Int, ciphertext []*big.Int, p *big.Int) []*big.Int {
	b12 := make([]*big.Int, 4)
	a12 := make([][]*big.Int, 4)
	for i := 0; i < 4; i++ {
		a12[i] = make([]*big.Int, 4)
	}

	choice := []int64{0, 3, 6, 5} //选择四个分片

	for i := 0; i < 4; i++ {
		b12[i] = ciphertext[choice[i]]
		a12[i] = coefficient[choice[i]]
	}

	sol2, _ := Solve(a12, b12, p)
	fmt.Print("decryptext: ")
	fmt.Println(sol2)

	var recoveredMessage string
	for i := 0; i < 4; i++ {
		// 将加密时高位添加的1去掉
		binaryStr := fmt.Sprintf("%b", sol2[i])
		recoveredMessage += binaryStr[1:]
	}
	fmt.Print("recoveredMessage:")
	fmt.Println(recoveredMessage)
	return sol2
}

func readToBytes(filename string) []byte {
	f, err := ioutil.ReadFile(filename)
	if err != nil {
		fmt.Println("read fail", err)
	}
	return f
}

func myRead(path string) string {
	// 读文件得到[]byte格式
	bytesFormat := readToBytes(path)
	// 将[]byte转为big.int
	intFormat := new(big.Int)
	intFormat.SetBytes(bytesFormat)
	// 将big.int转为二进制字符串
	binStr := fmt.Sprintf("%b", intFormat)
	return binStr
}

func initSecretSharing() {
	//初始化系数矩阵
	tempCoefficient := [7][4]int64{
		{1, 1, 1, 1},
		{1, 2, 3, 4},
		{1, 4, 9, 16},
		{1, 8, 27, 64},
		{1, 16, 81, 256},
		{1, 32, 243, 1024},
		{1, 64, 729, 4096}}

	coefficient := make([][]*big.Int, 7)
	for i := 0; i < 7; i++ {
		coefficient[i] = make([]*big.Int, 4)
	}

	for i := 0; i < 7; i++ {
		for j := 0; j < 4; j++ {
			coefficient[i][j] = new(big.Int).SetInt64(tempCoefficient[i][j])
		}
	}
	//messageStr := "110111001010101110011010101010101010010101010100010101010101010000101010101010100101110000001111110001111111100001111"

	//stdReader := bufio.NewReader(os.Stdin)
	//iotFilename, _ := stdReader.ReadString('\n')
	//iotFilename = strings.Replace(iotFilename, "\n", "", -1)
	iotFilename := "C:\\Users\\79843\\OneDrive\\大创\\Safe_Storage_System\\test.txt"
	messageStr := myRead(iotFilename)
	ciphertext, p := encrypt(coefficient, messageStr)
	//分片信息
	var results [][]byte
	// 将bigint格式的分片转为[]byte
	for _, bigInt := range ciphertext {
		bigStr := bigInt.String()
		results = append(results, []byte(bigStr))
	}
	fmt.Println(results)

	//物联网设备、模数等信息
	var datas []DATA
	for i := 0; i < 7; i++ {
		h := sha256.New()
		h.Write(results[i])
		hashedResult := h.Sum(nil)
		data := DATA{"000a43b", "0000f42e", time.Now(), i + 1, string(hashedResult), httpServerTable[i], p}
		data.Hash = hex.EncodeToString([]byte(data.Hash))
		datas = append(datas, data)
	}

	nodesNum := 7 //调试的时候写1，正式用改成7即可
	for i := 0; i < nodesNum; i++ {
		tempData, _ := json.Marshal(datas[i])
		d := new(DATA)
		err := json.Unmarshal(tempData, &d)
		if err != nil {
			log.Println(err)
		}
		//println(d)
		postSliceDataClient(results[i], tempData, httpServerTable[i])
	}
	decrypt(coefficient, ciphertext, p)
}
