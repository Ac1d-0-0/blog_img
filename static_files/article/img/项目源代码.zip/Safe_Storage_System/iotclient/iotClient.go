package main

import (
	"bytes"
	"fmt"
	"io"
	"math/big"
	"mime/multipart"
	"net/http"
	"time"
)

var httpServerTable []string

type DATA struct {
	DeviceId string
	UserId   string
	SavedAt  time.Time
	Serial   int //slice序号，0-6
	Hash     string
	StoreOn  string
	ModNum   *big.Int
}

func main() {
	//getClient()
	//postClient()
	//备用
	initHttpServerTable()
	initSecretSharing()

}

func initHttpServerTable() {
	httpServerTable = append(httpServerTable, "http://10.122.196.144:5001", "http://10.122.196.144:5002", "http://10.122.196.144:5003", "http://10.122.196.144:5004", "http://10.122.196.144:5005", "http://10.122.196.144:5006", "http://10.122.196.144:5007")
}

////get方法的请求，留用
//func getClient() {
//	//1.处理请求参数
//	params := url.Values{}
//	params.Set("name", "wang")
//	params.Set("age", "21")
//
//	//2.设置请求URL
//	rawUrl := serverURL + "/get"
//	reqURL, err := url.ParseRequestURI(rawUrl)
//	if err != nil {
//		fmt.Printf("url.ParseRequestURI()函数执行错误,错误为:%v\n", err)
//		return
//	}
//
//	//3.整合请求URL和参数
//	//Encode方法将请求参数编码为url编码格式("bar=baz&foo=quux")，编码时会以键进行排序。
//	reqURL.RawQuery = params.Encode()
//
//	//4.发送HTTP请求
//	//说明: reqURL.String() String将URL重构为一个合法URL字符串。
//	resp, err := http.Get(reqURL.String())
//	if err != nil {
//		fmt.Printf("http.Get()函数执行错误,错误为:%v\n", err)
//		return
//	}
//	defer resp.Body.Close()
//
//	//5.一次性读取响应的所有内容
//	body, err := ioutil.ReadAll(resp.Body)
//	if err != nil {
//		fmt.Printf("ioutil.ReadAll()函数执行出错,错误为:%v\n", err)
//		return
//	}
//	fmt.Println(string(body))
//}

//post方法的请求，留用
//func postClient() {
//	postURL := serverURL + "/post"
//	contentType := "application/json"
//	data := `{"name":"bing","age":20}`
//	response, err := http.Post(postURL, contentType, strings.NewReader(data))
//	if err != nil {
//		fmt.Println(err)
//		return
//	}
//	defer response.Body.Close()
//	body, err := ioutil.ReadAll(response.Body)
//	if err != nil {
//		fmt.Println(err)
//		return
//	}
//	fmt.Println("收到响应：", string(body))
//}

//post方法 发送multipart/form-data.
//slice和data一起发，均以byte[]形式
//func postSliceDataClient([]byte slice,[]byte data) 以这种形式传参
//func postSliceDataClient() {
func postSliceDataClient(slice []byte, data []byte, serverURL string) {
	postURL := serverURL + "/postSliceData"
	//contentType:="multipart/form-data"
	//准备两个bytes的reader 以二进制文件流形式输入
	sliceReader := bytes.NewReader(slice)
	dataReader := bytes.NewReader(data)

	body := new(bytes.Buffer)
	w := multipart.NewWriter(body)

	slicePart, err := w.CreateFormFile("slice", "slice")
	_, err = io.Copy(slicePart, sliceReader)
	if err != nil {
		fmt.Println(err)
	}

	dataPart, err := w.CreateFormFile("data", "data")
	_, err = io.Copy(dataPart, dataReader)
	if err != nil {
		fmt.Println(err)
	}

	w.Close()

	req, err := http.NewRequest("POST", postURL, body)
	if err != nil {
		fmt.Println(err)
		return
	}
	req.Header.Set("Content-Type", w.FormDataContentType())

	client := http.Client{Timeout: time.Second * 3}
	response, err := client.Do(req)
	if err != nil {
		fmt.Println("Post error:", err)
		return
	}
	defer response.Body.Close()
	//respBody, err := ioutil.ReadAll(response.Body)
	//if err != nil {
	//	fmt.Println(err)
	//	return
	//}  //可以客户端根据服务器状态进一步处理
	fmt.Println(response.Status)
	//fmt.Println("收到响应：", string(respBody))
}
