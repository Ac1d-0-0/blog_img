package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"
)

func httpServer() {
	//ip := GetOutboundIP()
	ip := "10.122.196.144"
	serverMux := http.NewServeMux()
	serverMux.HandleFunc("/getSlice", getSliceHandler)
	serverMux.HandleFunc("/getIndex", getIndexHandler)
	serverMux.HandleFunc("/postSliceData", postSliceDataHandler)

	go http.ListenAndServe(ip+":"+strconv.Itoa(config.HttpPort), serverMux)
}

//get方法检索获取切片位置和检索号的handler
func getIndexHandler(w http.ResponseWriter, r *http.Request) {
	defer r.Body.Close()
	log.Println("Receive get index request from ", r.RemoteAddr)

	params := r.URL.Query() //params的类型Values，就是map[string][]string
	startTime, _ := strconv.ParseInt(params.Get("startTime"), 10, 64)
	endTime, _ := strconv.ParseInt(params.Get("endTime"), 10, 64)
	data := GetData(params.Get("iotID"), time.Unix(startTime, 0), time.Unix(endTime, 0))
	fmt.Println(data)
	j, _ := json.Marshal(data)
	_, err := w.Write(j)
	if err != nil {
		log.Println(err)
	}

}

//get方法获得获取切片具体信息的handler
func getSliceHandler(w http.ResponseWriter, r *http.Request) {
	defer r.Body.Close()
	log.Println("Receive get slice request from ", r.RemoteAddr)

	params := r.URL.Query() //params的类型Values，就是map[string][]string
	slice := ExtractSlice(params.Get("hash"))
	_, err := w.Write(slice)
	if err != nil {
		log.Println(err)
	}

}

//post方法 发送multipart/form-data.
//收到并读出[]byte的slice和data后，会调用receiveSlice方法
func postSliceDataHandler(w http.ResponseWriter, r *http.Request) {
	defer r.Body.Close()
	log.Println("Receive SliceData request from ", r.RemoteAddr)

	err := r.ParseMultipartForm(128)
	if err != nil {
		log.Println(err)
	}

	if r.MultipartForm == nil {
		log.Println("error: MultipartForm is null")
	}
	var slice, data []byte
	if r.MultipartForm.File != nil {
		slice, data = parseMultipartFormFile(r)
	} else {
		log.Println("r.MultipartForm.File is null!")
	}
	fmt.Println("收到data!!!!!!!!")
	fmt.Println(data)
	receiveSlice(slice, data)
	w.WriteHeader(http.StatusOK)
}

// parse form data，读取表单类的数据，TODO：postHandler要用则为其适配
func parseMultipartFormValue(formValues map[string][]string) {
	for formName, values := range formValues {
		log.Printf("Value formname: %s\n", formName)
		for i, value := range values {
			log.Printf("      formdata[%d]: content=[%s]\n", i, value)

			//m := make(map[string]string)
			//_ = json.NewDecoder(strings.NewReader(value)).Decode(&m)
			//log.Printf("      formdata[%d]: json=[%v]\n", i, value)
		}
	}
	return
}

// parse form file，解析表单中二进制的数据
func parseMultipartFormFile(r *http.Request) (slice []byte, data []byte) {

	var formNameParams = [2]string{"data", "slice"}
	for _, formName := range formNameParams {
		formFile, formFileHeader, _ := r.FormFile(formName)

		log.Printf("File formname: %s, filename: %s, file length: %d\n", formName, formFileHeader.Filename, formFileHeader.Size)

		var b bytes.Buffer
		_, _ = io.Copy(&b, formFile)
		log.Printf("     formfile: content=[%s]\n", strings.TrimSuffix(b.String(), "\n"))
		if formName == "data" {
			data = b.Bytes()
		} else if formName == "slice" {
			slice = b.Bytes()
		}
	}
	return
}
