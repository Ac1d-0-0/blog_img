package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/emirpasic/gods/trees/avltree"
	"github.com/emirpasic/gods/utils"
	"log"
	"os"
	"time"
)

const (
	BackupFilePath = "./backup.txt"
)

const (
	MaxSerial = 7
)

var (
	backupFile *os.File
	reader     *bufio.Reader
	lastBlock  *Block
	tree       *avltree.Tree
)

type TreeKey struct {
	DeviceId string
	SavedAt  time.Time
	Serial   int
}

func TreeKeyComparator() utils.Comparator {
	return func(_a, _b interface{}) int {
		a := _a.(TreeKey)
		b := _b.(TreeKey)
		switch {
		case a.DeviceId < b.DeviceId:
			return -1
		case a.DeviceId > b.DeviceId:
			return 1
		default:
			switch {
			case a.SavedAt.Before(b.SavedAt):
				return -1
			case a.SavedAt.After(b.SavedAt):
				return 1
			default:
				switch {
				case a.Serial < b.Serial:
					return -1
				case a.Serial > b.Serial:
					return 1
				default:
					return 0
				}
			}
		}
	}
}

func initTraverser() {
	tree = avltree.NewWith(TreeKeyComparator())
}

func nextBlock() *Block {
	line, _, err := reader.ReadLine()
	if err != nil {
		return nil
	}
	var block Block
	err = json.Unmarshal(line, &block)
	if err != nil {
		panic(err)
	}
	if lastBlock != nil && !isBlockValid(block, *lastBlock) {
		panic(errors.New("invalid block"))
	}
	lastBlock = &block
	return &block
}

func InsertBlock(block *Block) {
	fmt.Println(block.Data)
	for _, data := range block.Data {
		fmt.Println(data)
		if data.Hash == "" {
			break
		}
		fmt.Println(data)
		fmt.Println(tree.Size())
		tree.Put(TreeKey{DeviceId: data.DeviceId, SavedAt: data.SavedAt, Serial: data.Serial}, data)
	}
}

func buildTraverser() {
	initTraverser()
	var err error
	backupFile, err = os.OpenFile(BackupFilePath, os.O_RDONLY, os.FileMode(0644))
	if err != nil {
		log.Print(err)
		return
	}
	reader = bufio.NewReader(backupFile)
	for {
		block := nextBlock()
		if block == nil {
			break
		}
		InsertBlock(block)
	}
}

func GetData(deviceId string, startTime time.Time, endTime time.Time) []DATA {
	if tree.Size() == 0 {
		return []DATA{}
	}
	floor, found := tree.Floor(TreeKey{DeviceId: deviceId, SavedAt: startTime, Serial: 1})
	if !found {
		floor = tree.Left()
	}
	if floor.Key.(TreeKey).DeviceId != deviceId || floor.Key.(TreeKey).SavedAt.Before(startTime) {
		floor = floor.Next()
	}
	if floor == nil || floor.Key.(TreeKey).DeviceId != deviceId {
		return []DATA{}
	}
	ceiling, found := tree.Ceiling(TreeKey{DeviceId: deviceId, SavedAt: endTime, Serial: MaxSerial})
	if !found {
		ceiling = tree.Right()
	}
	if ceiling.Key.(TreeKey).DeviceId != deviceId || ceiling.Key.(TreeKey).SavedAt.After(endTime) {
		ceiling = ceiling.Prev()
	}
	if ceiling == nil || ceiling.Key.(TreeKey).DeviceId != deviceId {
		return []DATA{}
	}
	var data []DATA
	for {
		data = append(data, floor.Value.(DATA))
		if floor == ceiling {
			break
		}
		floor = floor.Next()
	}
	return data
}
