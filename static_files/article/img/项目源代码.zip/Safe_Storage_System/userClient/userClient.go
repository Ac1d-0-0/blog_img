package main

import (
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"math/big"
	"math/rand"
	"net/http"
	"net/url"
	"strconv"
	"time"
)

//const layout = "2006-01-02 15:04:05 (MST)"
const layout = "2006-01-02 15:04:05 (MST)"

var serverURL string

var httpServerTable []string

type DATA struct {
	DeviceId string
	UserId   string
	SavedAt  time.Time
	Serial   int
	Hash     string
	StoreOn  string
	ModNum   *big.Int
}

func main() {
	serverURL = initHttpServerTable()
	startTime, _ := time.Parse(layout, "2020-12-08 14:13:35 (CST)")
	//startTime2, _ := time.Parse(layout, "2020-12-08 10:37:36 (UTC)") //UTC返回时间戳；以layout形式解析，没有毫秒；仅是为了方便测试
	//startTime:=time.Date(2020,time.Month(11),22,18,58,18,30,time.UTC)//先随便定了个时间，将来应该改成某种输入
	//startTime:=time.Unix(1606086515,336677)
	//fmt.Println(startTime.Unix())
	//fmt.Println(startTime2.Unix())
	endTime := startTime.Add(10 * time.Minute)
	//fmt.Println(strconv.FormatInt(endTime.Unix(), 10))
	userGetIndex(startTime, endTime, "000a43b", "0000f42e")
}

func initHttpServerTable() string {
	httpServerTable = append(httpServerTable, "http://10.122.196.144:5001", "http://10.122.196.144:5002", "http://10.122.196.144:5003", "http://10.122.196.144:5004", "http://10.122.196.144:5005", "http://10.122.196.144:5006", "http://10.122.196.144:5007")
	rand.Seed(time.Now().Unix())
	return httpServerTable[6]
}

//用户端使用get方法发起请求，获取保存切片的信息
//起止时间都是Time型对象，在调用前应当通过某些方法构造
//get请求时，所有参数都为string
func userGetIndex(startTime time.Time, endTime time.Time, iotID string, userID string) {
	//1.处理请求参数
	params := url.Values{}
	params.Set("startTime", strconv.FormatInt(startTime.Unix(), 10))
	params.Set("endTime", strconv.FormatInt(endTime.Unix(), 10))
	params.Set("iotID", iotID)
	params.Set("userID", userID)

	//2.设置请求URL
	rawUrl := serverURL + "/getIndex"
	reqURL, err := url.ParseRequestURI(rawUrl)
	if err != nil {
		log.Fatalf("url.ParseRequestURI()函数执行错误,错误为:%v\n", err)
		return
	}

	//3.整合请求URL和参数
	//Encode方法将请求参数编码为url编码格式("bar=baz&foo=quux")，编码时会以键字母进行排序。
	reqURL.RawQuery = params.Encode()

	//4.发送HTTP请求
	//说明: reqURL.String() String将URL重构为一个合法URL字符串。
	//eg: http://127.0.0.1:5000/getIndex?endTime=1606086515&iotID=aabbccdd&startTime=1606072115&userID=11223344
	resp, err := http.Get(reqURL.String())
	if err != nil {
		fmt.Printf("http.Get()函数执行错误,错误为:%v\n", err)
		return
	}
	defer resp.Body.Close()

	//5.一次性读取响应的所有内容
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Printf("ioutil.ReadAll()函数执行出错,错误为:%v\n", err)
		return
	}
	//body是[]byte，这里仅转成16进制输出
	//fmt.Println(hex.Dump(body))

	var indexs []DATA
	err = json.Unmarshal(body, &indexs)
	for _, tmp := range indexs {
		fmt.Println(tmp)
	}
	if err != nil {
		log.Println("json解析出错，错误为：", err)
		return
	}

	for i := 0; i < len(indexs); i += 7 {
		sliceGet := 0
		slices := make([]*big.Int, 4)
		choice := make([]int64, 4)
		for j := 0; j < 7; j++ {
			temp, _ := userGetSlice(indexs[i+j].StoreOn, indexs[i+j].Hash)
			if temp != nil {
				tempCiphertext := new(big.Int)
				tempCiphertext.SetString(string(temp), 10)
				fmt.Println(tempCiphertext)
				slices[sliceGet] = tempCiphertext
				choice[sliceGet] = int64(indexs[i+j].Serial) - 1
				sliceGet++
			}
			if sliceGet == 4 {
				fmt.Println(indexs[i+j].ModNum)
				_, err = recoverMessage(slices, indexs[i+j].ModNum, choice)
				if err != nil {
					log.Println("还原失败，将全部get然后尝试组合恢复。")
					var indexForFailGet []DATA
					for k := 0; k < 7; k++ {
						indexForFailGet[k] = indexs[i+k]
					}
					decryptFailGet(indexForFailGet)
					continue
				}
				break
			}
		}
	}

}

func decryptFailGet(index []DATA) (recoveredMessage string, decryptErr error) {
	existSliceFlag := 88
	slices := make([]*big.Int, 7)
	choice := make([]int64, 7)
	for j := 0; j < 7; j++ {
		temp, err := userGetSlice(index[j].StoreOn, index[j].Hash)
		if err != nil {
			log.Println(index[j].ModNum, "stored on", index[j].StoreOn, "get failed.")
			slices[j] = new(big.Int)
			choice[j] = 88
			continue
		}
		if temp != nil {
			log.Println(index[j].ModNum, "stored on", index[j].StoreOn, "get succeed.")
			tempCiphertext := new(big.Int)
			tempCiphertext.SetBytes(temp)
			slices[j] = tempCiphertext
			choice[j] = int64(j)
			existSliceFlag = j
		}
	}
	if existSliceFlag == 88 {
		log.Println("all get failed! ")
		return "", errors.New("ALL GET FAILED")
	}
	m := 4
	n := len(choice) //7
	indexInCombine := combineResult(n, m)
	result := findNumsByIndexs(choice, indexInCombine)
	fmt.Println("count:", len(result))
	fmt.Println("result:", result)
	for _, choiceI := range result {
		badChoice := false
		for _, v := range choiceI {
			if v == 88 {
				badChoice = true
				break
			}
		}
		if !badChoice {
			log.Println("bad choice") //TODO:展示出来哪个choice是bad
			continue
		}
		recoveredMessage, err := recoverMessage(slices, index[existSliceFlag].ModNum, choiceI)
		if err != nil {
			log.Println("decrypt succeed! with choice", choiceI)
			return recoveredMessage, err
		}
	}
	log.Println("all decrypt failed! ")
	return "", errors.New("ALL DECRYPT FAILED")
}

//用户端使用get方法发起请求，获取slice
func userGetSlice(addr, hash string) ([]byte, error) {
	params := url.Values{}
	params.Set("hash", hash)

	rawUrl := addr + "/getSlice"
	reqURL, err := url.ParseRequestURI(rawUrl)
	if err != nil {
		log.Printf("url.ParseRequestURI()函数执行错误,错误为:%v\n", err)
		return nil, err
	}

	reqURL.RawQuery = params.Encode()
	resp, err := http.Get(reqURL.String())
	if err != nil {
		log.Printf("http.Get()函数执行错误,错误为:%v\n", err)
		return nil, err
	}
	defer resp.Body.Close()

	slice, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Printf("ioutil.ReadAll()函数执行出错,错误为:%v\n", err)
		return nil, err
	}
	if len(slice) == 0 {
		log.Println("slice's len == 0, return nil.")
		return nil, err
	}
	//slice是[]byte，这里仅转成16进制输出

	fmt.Println(hex.Dump(slice))
	return slice, nil
}

func recoverMessage(ciphertext []*big.Int, p *big.Int, choice []int64) (recoveredMessage string, decryptErr error) {
	fmt.Println(choice)
	tempCoefficient := [7][4]int64{
		{1, 1, 1, 1},
		{1, 2, 3, 4},
		{1, 4, 9, 16},
		{1, 8, 27, 64},
		{1, 16, 81, 256},
		{1, 32, 243, 1024},
		{1, 64, 729, 4096}}

	coefficient := make([][]*big.Int, 7)
	for i := 0; i < 7; i++ {
		coefficient[i] = make([]*big.Int, 4)
	}
	for i := 0; i < 7; i++ {
		for j := 0; j < 4; j++ {
			coefficient[i][j] = new(big.Int).SetInt64(tempCoefficient[i][j])
		}
	}
	b12 := make([]*big.Int, 4)
	a12 := make([][]*big.Int, 4)
	for i := 0; i < 4; i++ {
		a12[i] = make([]*big.Int, 4)
	}

	//choice := []int64{0, 1, 2, 3} //选择四个分片

	for i := 0; i < 4; i++ {
		b12[i] = ciphertext[i]
		a12[i] = coefficient[choice[i]]
	}
	sol2, err := Solve(a12, b12, p)
	if !err {
		var choiceString string
		for _, i := range choice {
			choiceString += " " + strconv.FormatInt(i, 10)
		}
		return "", errors.New(choiceString)
	}
	fmt.Print("decryptext: ")
	fmt.Println(sol2)

	for i := 0; i < 4; i++ {
		// 将加密时高位添加的1去掉
		binaryStr := fmt.Sprintf("%b", sol2[i])
		recoveredMessage += binaryStr[1:]
	}

	recoveredMessageBigInt := new(big.Int)
	recoveredMessageBigInt.SetString(recoveredMessage, 2)
	_ = ioutil.WriteFile("./recoverMessage.txt", recoveredMessageBigInt.Bytes(), 0777)
	fmt.Println(recoveredMessageBigInt.String())
	return recoveredMessage, nil
}
