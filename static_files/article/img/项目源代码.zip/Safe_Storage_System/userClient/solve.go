package main

import (
	//"fmt"
	"math"
	"math/big"
)

func MaxAbs(a []int64) (float64, int, bool) {
	/*
		向量第一个绝对值最大值及其位置
		输入   :
		    a       a 被处理向量
		输出   :
		    sol     解值
		    ii      第一个最大值位置
		    err     解出标志：false-未解出或达到步数上限；
		                     true-全部解出
	*/
	var sol float64
	var ii int
	var err = false

	n := len(a)
	ii = 0
	sol = float64(a[ii])
	for i := 1; i < n; i++ {
		if math.Abs(sol) < math.Abs(float64(a[i])) {
			ii = i
			sol = float64(a[i])
		}
	}

	err = true
	return sol, ii, err
}

//(a * b逆)%p
func calculate(a *big.Int, b *big.Int, p *big.Int) *big.Int {
	var temp *big.Int
	temp = new(big.Int)
	temp.ModInverse(b, p)
	temp.Mul(temp, a)
	temp.Mod(temp, p)
	return temp
}

// LEs_ECPE 线性代数方程组的列主元消去法
func Solve(a [][]*big.Int, b []*big.Int, p *big.Int) ([]*big.Int, bool) {

	/*
		线性代数方程组的列主元消去法
		输入   :
		    a       a x = b线性代数方程组的系数矩阵
		    b       a x = b线性代数方程组的右侧常数列向量
		输出   :
		    sol     解值
		    err     解出标志：false-未解出或达到步数上限；
		                     true-全部解出
	*/
	//方程个数为n
	var err = false
	atemp := a
	btemp := b
	n := len(btemp)
	sol := make([]*big.Int, n)
	temp0 := make([]*big.Int, n)
	var temp1 *big.Int

	// 输入判断
	if len(atemp) != n {
		return sol, err
	}

	//求解
	//消去，求得上三角矩阵
	for i := 0; i < n-1; i++ {
		//求第i列的主元素并调整顺序
		acol := make([]int64, n-i)
		for icol := i; icol < n; icol++ {
			acol[icol-i] = atemp[icol][i].Int64()
		}
		_, ii, _ := MaxAbs(acol)
		if ii+i != i {
			temp0 = atemp[ii+i]
			atemp[ii+i] = atemp[i]
			atemp[i] = temp0
			temp1 = btemp[ii+i]
			btemp[ii+i] = btemp[i]
			btemp[i] = temp1
		}

		//列消去
		for j := i + 1; j < n; j++ {
			//mul := (atemp[j][i] * (Inverse((atemp[i][i]),p))%p+p)%p
			//mul := atemp[j][i] / atemp[i][i]
			mul := calculate(atemp[j][i], atemp[i][i], p)
			for k := i; k < n; k++ {
				//atemp[j][k] = ((atemp[j][k] - atemp[i][k]*mul)%p+p)%p
				var t1 *big.Int
				t1 = new(big.Int)
				t1.Mul(mul, atemp[i][k])
				t1.Sub(atemp[j][k], t1)
				atemp[j][k].Mod(t1, p)
			}
			//btemp[j] = ((btemp[j] - btemp[i]*mul)%p+p)%p
			var t2 *big.Int
			t2 = new(big.Int)
			t2.Mul(mul, btemp[i])
			t2.Sub(btemp[j], t2)
			btemp[j].Mod(t2, p)
		}
	}
	//fmt.Println(atemp)
	//fmt.Println(btemp)
	//回代
	//sol[n-1] = (btemp[n-1] * (Inverse((atemp[n-1][n-1]),p))%p+p)%p
	//sol[n-1] = btemp[n-1] / atemp[n-1][n-1]
	sol[n-1] = calculate(btemp[n-1], atemp[n-1][n-1], p)
	for i := n - 2; i >= 0; i-- {
		temp1 = big.NewInt(0)
		for j := i + 1; j < n; j++ {
			var temp2 *big.Int
			temp2 = new(big.Int)
			temp2.Mul(atemp[i][j], sol[j])
			temp1.Add(temp1, temp2)
		}
		//sol[i] = ((btemp[i] - temp1) * (Inverse((atemp[i][i]),p))%p+p)%p
		//sol[i] = (btemp[i] - temp1) / atemp[i][i]
		sol[i] = calculate(temp1.Sub(btemp[i], temp1), atemp[i][i], p)
	}

	//返回结果
	err = true
	return sol, err
}
