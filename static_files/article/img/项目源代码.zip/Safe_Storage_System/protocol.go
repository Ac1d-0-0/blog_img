package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"net/http"
)

var nodeID = 1

type Pack struct {
	nodeID, packetID, typeID, length int
	content                          []byte
}

func Enpack(pack Pack) []byte {
	message := IntToBytes(pack.nodeID)
	var temp = append(append(append(append(message, IntToBytes(pack.packetID)...), IntToBytes(pack.typeID)...), IntToBytes(pack.length)...), pack.content...)
	return temp
}

func Unpack(message []byte) Pack {
	var pack Pack
	pack.nodeID = ByteToInt(message[0:4])
	pack.packetID = ByteToInt(message[4:8])
	pack.typeID = ByteToInt(message[8:12])
	pack.length = ByteToInt(message[12:16])
	pack.content = message[16:]
	return pack
}

func ByteToInt(n []byte) int {
	bytesbuffer := bytes.NewBuffer(n)
	var x int32
	binary.Read(bytesbuffer, binary.BigEndian, &x)
	return int(x)
}

func IntToBytes(n int) []byte {
	x := int32(n)
	bytesBuffer := bytes.NewBuffer([]byte{})
	binary.Write(bytesBuffer, binary.BigEndian, x)
	return bytesBuffer.Bytes()
}

func heartBeat(typeID int) {
	var hiPack Pack
	hiPack.nodeID = nodeID
	hiPack.packetID = 1
	hiPack.typeID = typeID
	hiPack.length = 16
	heartPack := Enpack(hiPack)
	//调用发送
	for nodeId, URL := range urlList {
		if nodeId == config.NodeId {
			continue
		} else {
			sendResult := node.sendData(URL, heartPack)
			if !sendResult {
				//TODO:心跳
			}

		}
	}
}

func broadcastBlock(block []byte) {
	var blockPack Pack
	blockPack.nodeID = nodeID
	blockPack.packetID = 1
	blockPack.typeID = 200
	blockPack.content = block
	blockPack.length = 16 + blockPack.length
	pack := Enpack(blockPack)
	for nodeId, URL := range urlList {
		if nodeId == config.NodeId {
			continue
		} else {
			node.sendData(URL, pack)
		}
	}
}

func requestAllBlocks() {
	var blockPack Pack
	blockPack.nodeID = nodeID
	blockPack.packetID = 1
	blockPack.typeID = 401
	blockPack.length = 16 + blockPack.length
	Enpack(blockPack)
}

func resolveFunc(w http.ResponseWriter, r *http.Request, bPack []byte) {
	var receivedPack Pack
	receivedPack = Unpack(bPack)
	switch receivedPack.typeID {
	//hello
	case 100:
		println("receice heartbeat from: ", receivedPack.nodeID)
		w.WriteHeader(http.StatusOK)
	//hello response
	case 101:
		println("heartbeat response")
	case 200:
		println("收到区块")
		block := Block{}
		temp := receivedPack.content
		json.Unmarshal(temp, &block)
		storeBlock(block)
		w.WriteHeader(http.StatusOK)
		r.Body.Close()
		if config.NodeId == block.NextBlockGenerator {
			getToken()
		}
	case 201:
		println("收到自宕机之后的所有区块")
		//TODO:宕机恢复
	case 400:
		println("node unreachable")
		//TODO:节点不可达，更新list
	case 401:
		println("node restart")
		//TODO:节点重启，恢复
	}
}
