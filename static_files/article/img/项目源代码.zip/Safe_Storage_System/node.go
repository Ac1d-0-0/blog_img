package main

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"time"
)

// Node type - a p2p host implementing http
// 以http服务为基础的p2p节点
type Node struct {
	ip        string
	port      int
	URL       string //"ip:port", listening URL for http_p2p; node's identifier
	P2PServer *http.ServeMux
}

//依据port端口信息创建节点
func makeNode(port int) *Node {
	myIP := GetOutboundIP()
	listenAddr := fmt.Sprintf("http://%s:%d", myIP, port)
	serverMux := http.NewServeMux()
	node := &Node{URL: listenAddr, ip: myIP, port: port, P2PServer: serverMux}
	node.NewP2PProtocol()
	go http.ListenAndServe(fmt.Sprintf("%s:%d", myIP, port), serverMux)
	return node
}

//Node的方法，以POST方法实现发送区块信息。
func (e *Node) sendP2PMessage(serverURL string, data []byte) error {
	postURL := serverURL + "/postHttpP2P"

	packReader := bytes.NewReader(data)

	body := new(bytes.Buffer)
	w := multipart.NewWriter(body)

	contentPart, err := w.CreateFormFile("block", "block")
	_, err = io.Copy(contentPart, packReader)
	if err != nil {
		return err
	}
	w.Close()

	req, err := http.NewRequest("POST", postURL, body)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", w.FormDataContentType())

	client := http.Client{Timeout: time.Second * 10}
	response, err := client.Do(req)
	if err != nil {
		return err
	}
	defer response.Body.Close()
	return nil
}

//Node的方法，调用发送实现和进行错误处理。进一步有了签名还可以做加密等工作。
func (e *Node) sendData(targetURL string, data []byte) bool {
	log.Printf("Sending data to:%s......", targetURL)
	err := e.sendP2PMessage(targetURL, data)
	if err != nil {
		log.Println("failed to send data.", err)
		return false
	}
	log.Printf("Data to: %s was sent.", targetURL)
	return true
}
