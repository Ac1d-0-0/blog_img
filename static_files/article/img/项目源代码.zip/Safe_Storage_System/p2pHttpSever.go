package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strconv"
	"strings"
)

//为Node类对象的httpserver配置处理函数
func (e *Node) NewP2PProtocol() {
	e.P2PServer.HandleFunc("/postHttpP2P", postHttpP2PHandler)
	e.P2PServer.HandleFunc("/postConnectionInfo", postConnectionInfo)
	e.P2PServer.HandleFunc("/getConnectionInfo", getConnectionInfo)
}

//http_P2P post方法传送block的handler
func postHttpP2PHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("Receive http_p2p request from ", r.RemoteAddr)

	err := r.ParseMultipartForm(128)
	if err != nil {
		log.Println(err)
	}
	if r.MultipartForm == nil {
		log.Println("error: MultipartForm is null")
	}
	var pack []byte
	if r.MultipartForm.File != nil {
		pack = parseMultipartFormFileForP2P(r)
	} else {
		log.Println("r.MultipartForm.File is null!")
	}
	fmt.Println(pack)
	resolveFunc(w, r, pack)
}

//用于接收其他节点传输过来的上线信息。
func postConnectionInfo(w http.ResponseWriter, r *http.Request) {
	defer r.Body.Close()
	err := r.ParseMultipartForm(128)
	if err != nil {
		fmt.Println(err)
		return
	}
	_nodeId := r.Form.Get("node_id")
	nodeId, err := strconv.Atoi(_nodeId)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		log.Println("Invalid request")
		return
	}
	URL := r.Form.Get("URL")
	updateConnectionInfo(nodeId, URL)
	if sig != nil {
		sig <- struct{}{}
	}
	w.WriteHeader(http.StatusOK)
}

func getConnectionInfo(w http.ResponseWriter, r *http.Request) {
	defer r.Body.Close()
	j, _ := json.Marshal(map[string]string{
		"addr": myURL,
	})
	w.Header().Add("Content-Type", "application/json")
	_, err := w.Write(j)
	if err != nil {
		panic(err)
	}
	w.WriteHeader(http.StatusOK)
}

// parse form file，解析表单中二进制的数据。只有block，实现原理一样但相对简化。
func parseMultipartFormFileForP2P(r *http.Request) []byte {

	var formName = "block"
	formFile, formFileHeader, _ := r.FormFile(formName)

	log.Printf("File formname: %s, filename: %s, file length: %d\n", formName, formFileHeader.Filename, formFileHeader.Size)

	var b bytes.Buffer
	_, _ = io.Copy(&b, formFile)
	log.Printf("     formfile: content=[%s]\n", strings.TrimSuffix(b.String(), "\n"))

	return b.Bytes()
}
