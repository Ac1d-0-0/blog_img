package main

import (
	"bytes"
	"encoding/binary"
	"io/ioutil"
	"log"
	"os"
)

var (
	SLICEHEAD = []byte{
		0x53, 0x4c, 0x43, 0x01,
	}
)

func fileToBytes(path string) []byte {
	f, err := os.Open(path)
	if err != nil {
		panic(err)
	}
	defer f.Close()
	fd, err := ioutil.ReadAll(f)
	if err != nil {
		panic(err)
	}
	return fd
}

func StoreSlice(slice []byte, data DATA) bool {
	sliceLen := len(slice)
	filename := data.Hash
	print(filename)
	file, err := os.OpenFile("./slice/"+filename+".slc", os.O_WRONLY|os.O_CREATE, os.ModePerm)
	defer file.Close()
	if err != nil {
		log.Panic(err)
		return false
	}
	if sliceLen > 0 {
		file.Write(SLICEHEAD)
		file.Write(IntToBytes(sliceLen))
		file.Write(slice)
		return true
	}
	return true
}

func ExtractSlice(hash string) []byte {
	filePath := "./slice/" + hash + ".slc"
	file, err := os.OpenFile(filePath, os.O_RDONLY, os.ModePerm)
	if err != nil {
		log.Panic(err)
	}
	defer file.Close()
	fileinfo, _ := file.Stat()
	filesize := fileinfo.Size()
	buffer := make([]byte, filesize)

	_, err = file.Read(buffer)
	if err != nil {
		log.Panic(err)
	}
	sliceLen := BytesToInt(buffer[4:8][:])
	slice := buffer[8:][:]
	if sliceLen == len(slice) {
		return slice
	}
	return nil
}

func BytesToInt(b []byte) int {
	bytesBuffer := bytes.NewBuffer(b)
	var x int32
	binary.Read(bytesBuffer, binary.BigEndian, &x)
	return int(x)
}
